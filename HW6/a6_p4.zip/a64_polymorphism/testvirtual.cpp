/*
CH08-320142
a6_p4 .cpp
Brian Sherif Nazmi Hanna Nasralla
B.hannanasralla@jacobs-university.de
*/
#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

std::string color() {
  std::string b[4] = {"RED", "YELLOW", "BLUE", "GREEN"};
  int generator;
  generator = rand();
  return b[generator%4];
}
std::string shapes() {
  std::string b[4] = {"Circle", "Rectangle", "Square", "Ring"};
  int generator;
  generator = rand();
  return b[generator%4];
}
std::string size () {
  int b[50] = {1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10 ,11 ,12 ,13 ,14 ,15 ,16 ,17 ,18 ,19 ,20 ,21 ,22 ,23 ,24 ,25 ,26 ,27 ,28 ,29 ,30 ,31 ,32 ,33 ,34 ,35 ,36 ,37 ,38 ,39 ,40 ,41 ,42 ,43 ,44 ,45 ,46 ,47 ,48 ,49 ,50};
  int generator;
  generator = rand();
  return b[generator%50];
}

const int num_obj = 7;
int main() {
	srand(time(0));
	Area *list[num_obj];						// The creation of an array with the num_obj for elements which is equal to 6
	int index = 0;								// Intiation of an int named index which is equal to zero for use in a while loop so it can increase with every loop.
	std::string x = shapes()
	double sum_area = 0.0;						// Intiating a double variable named sum_area and setting it to zero which is then implemnted in the while loop to calculate the sum of areas for all the shapes created.
 do {
	 for (int i = 0; i < 19; i++) {
		 list [i] = &y
switch (x==) {

	case "Circle" :
	z = color()
	c = size()
	cout << "Creating Circle: ";
	y = Circle circle(z, c);
	case "Rectangle":
	z = color()
	c = size()
	v = size()
	cout << "Creating Rectangle: ";
	y = Rectangle rectangle(z, c, v);
	case "Square":
	z = color()
	c = size()
	cout << "Creating Square: ";
	y = Square square(z, c, c);
	case "Ring":
	z = color()
	c = size()
	v = size()
	cout << "Creating Ring: ";
	y = Ring ring(z, c, v);
}
} while(index < 19);

	while (index < num_obj) {					// While loop created to call the function calcArea for each and every object. this is done by creating an index zero which is then incresed with every loop till as long as it is small then the total number of objects (6 in this case)
		(list[index])->getColor();				// Append to every index in list the color of the object
		sum_area += (list[index++])->calcArea();
	}
	cout << "\nThe total area is "
			<< sum_area << " units " << endl;	// Print on the screen the total sum of areas

      int index2 = 0
      double sum_peri = 0.0;
      while (index2 < num_obj) {					// While loop created to call the function calcPeri for each and every object. this is done by creating an index zero which is then incresed with every loop till as long as it is small then the total number of objects (6 in this case)
        sum_peri += (list[index2++])->calcPeri();
      }
      cout << "\nThe total Perimeter is "
          << sum_peri << " units " << endl;	// Print on the screen the total sum of Perimeter
  return 0;
}
/* diagram how these classes relate
       +--------+
       |  Area  |
    +--+--------+---+
    |               |
    |               |
    |               |
    |               |
+-----v-----+     +-v------+
| Rectangle |     | Circle |
+-----------+     +------+-+
                    |
                    |
                    |
                  +-v------+
                  |  Ring  |
                  +--------+


*/
