/*
CH08-320142
a6_p4 .cpp
Brian Sherif Nazmi Hanna Nasralla
B.hannanasralla@jacobs-university.de
*/
#ifndef _SQUARE_H
#define _SQUARE_H
#include "Rectangle.h"
#include "Area.h"
class Square : public virtual Rectangle {
	public:
		Square(const char *n, double a, double b);
		~Square();
		double calcArea() const;
		double calcPeri() const;
	private:
		double length;
		double width;
};

#endif
