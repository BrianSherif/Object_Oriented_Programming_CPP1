/*
CH08-320142
a6_p3 .cpp
Brian Sherif Nazmi Hanna Nasralla
B.hannanasralla@jacobs-university.de
*/
#include <iostream>
#include "Square.h"

Square::Square(const char *n, double a, double b) : Area(n) {
    length = width = a = b
  }

Square::~Square() {
}

double Square::calcArea() const {
  std::cout << "calcArea of Square...";
	return length*width;
}
double Square::calcPeri() const {
  std::cout << "calcPeri of Square...";
	return (length*2)+(width*2);
}
