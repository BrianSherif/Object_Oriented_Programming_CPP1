/*
CH08-320142
a6_p3 .cpp
Brian Sherif Nazmi Hanna Nasralla
B.hannanasralla@jacobs-university.de
*/
#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

const int num_obj = 7;
int main() {
	Area *list[num_obj];						// The creation of an array with the num_obj for elements which is equal to 6
	int index = 0;								// Intiation of an int named index which is equal to zero for use in a while loop so it can increase with every loop.
	double sum_area = 0.0;						// Intiating a double variable named sum_area and setting it to zero which is then implemnted in the while loop to calculate the sum of areas for all the shapes created.
	cout << "Creating Ring: ";
	Ring blue_ring("BLUE", 5, 2);				// Constructing the objects and assigning all the neccesary parameters
	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);
	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN",5,6);
	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);
	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);
  cout << "Creating Square: ";
	Square pink_rectangle("pink", 13, 13);
	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);
	list[0] = &blue_ring;						// Assigning the objects into an array. This is done by assigning the address in the array then equating it to the reference '&' of a certain object.
	list[1] = &yellow_circle;       // this is useful as it will allow us to sum up the area and assign them to the same location within the array
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
	while (index < num_obj) {					// While loop created to call the function calcArea for each and every object. this is done by creating an index zero which is then incresed with every loop till as long as it is small then the total number of objects (6 in this case)
		(list[index])->getColor();				// Append to every index in list the color of the object
		sum_area += (list[index++])->calcArea();
	}
	cout << "\nThe total area is "
			<< sum_area << " units " << endl;	// Print on the screen the total sum of areas

      int index2 = 0
      double sum_peri = 0.0;
      while (index2 < num_obj) {					// While loop created to call the function calcPeri for each and every object. this is done by creating an index zero which is then incresed with every loop till as long as it is small then the total number of objects (6 in this case)
        sum_peri += (list[index2++])->calcPeri();
      }
      cout << "\nThe total Perimeter is "
          << sum_peri << " units " << endl;	// Print on the screen the total sum of Perimeter
  return 0;
}
/* diagram how these classes relate
       +--------+
       |  Area  |
    +--+--------+---+
    |               |
    |               |
    |               |
    |               |
+-----v-----+     +-v------+
| Rectangle |     | Circle |
+-----------+     +------+-+
                    |
                    |
                    |
                  +-v------+
                  |  Ring  |
                  +--------+


*/
